import React from 'react';

export default class LifeCycleHooksComponent extends React.Component{      
      
    constructor(props){
            super(props);
            this.state = {companyName:''};           
    }

    componentWillMount(){
            // Initialization code !
            console.log('componentWillMount');
    }

    componentDidMount(){
        console.log('componentDidMount');
    }
    shouldComponentUpdate(){
        console.log('shouldComponentUpdate');
        console.log(this.state);
        console.log(arguments);
        return true;
    }
    componentWillUpdate(){
        console.log('componentWillUpdate');
        console.log(this.state);

    }
    componentDidUpdate(){
        console.log('componentDidUpdate');
    }

    OnChangeHandler(){
       var company = this.refs.txtCompany.value;
       this.setState({companyName:company});
       console.log('More Lines Of Code..');

    }
    render(){   
        console.log('Render..');
        console.log(this.state);

      return <div>
                    Company Name :     <input type="text" 
                    ref="txtCompany"
                    onChange={this.OnChangeHandler.bind(this)} />
                        <h1> {this.state.companyName}</h1>
          </div>
    }
}

