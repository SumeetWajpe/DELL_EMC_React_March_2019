import React from 'react';
import CustomButton from './burron.component';

export default class ListOfButtonsComponent extends React.Component{
   
    constructor(){
        super();
        this.state ={buttonlist: [10,20,30,40,50]};
    }   
    AddNewButton(){      
        var newButton = +(this.refs.txtInput.value);
        this.setState({buttonlist:[...this.state.buttonlist,newButton]})
        //  this.state.buttonlist.push(60);
        // this.setState({buttonlist:this.state.buttonlist})
    }
    DeleteAButton(){
        // delete the button !
        var buttonToBeDeleted = +(this.refs.txtInput.value);
       // var index = this.state.buttonlist.findIndex(i=> i == buttonToBeDeleted)
       // slice before and after !
       // OR
       var theNewList = this.state.buttonlist.filter(v => v != buttonToBeDeleted)
       console.log('New List : ' + theNewList);
       this.setState({buttonlist:theNewList});
       console.log(this.state.buttonlist);
    }

    ParentHandler(theCount){
        console.log('Parent Handler !' +  theCount);
    }
    render(){
        var btnsToBeCreated = this.state.buttonlist.map(b => 
        <CustomButton count={b} key={b}   
        handlerfromparent={this.ParentHandler}  />)
        return <div>
            <p> Add New Button : <input type="number" ref="txtInput" />
            <input type="button" 
            onClick={this.AddNewButton.bind(this)}
            value="Add"
            className="btn btn-success"           
            />

            <input type="button" 
            onClick={this.DeleteAButton.bind(this)}
            value="Delete"
            className="btn btn-danger"           
            />
            </p>
            {btnsToBeCreated}
        </div>
    }
}

