import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import ListOfButtonsComponent from './listofbuttons.component';
import LifeCycleHooksComponent from './lifecyclehooks';
import PostsComponent from './ajaxusingaxios';

// ReactDOM.render(<App />, document.getElementById('root'));
// ReactDOM.render(<ListOfButtonsComponent />, document.getElementById('root'));
// ReactDOM.render(<LifeCycleHooksComponent/>,document.getElementById('root'))
ReactDOM.render(<PostsComponent/>,document.getElementById('root'))

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
