import React from 'react';
import axios from 'axios';

export default class PostsComponent extends React.Component{      
    constructor(props){
        super(props);
        this.state = {allPosts:[]};
    }
    componentDidMount(){
        axios.get('https://jsonplaceholder.typicode.com/posts')
        .then((response)=>{
                this.setState({allPosts:response.data});
            },
            (err)=>{console.log(err)}
        )
    } 
    render(){  
        var postsToBeCreated = this.state.allPosts.map(p=><li key={p.id}>{p.title}</li>)
      return <div>
                <h1> All Posts</h1>
                <ul>
                    {postsToBeCreated}
                </ul>
      </div>  
    }
}

