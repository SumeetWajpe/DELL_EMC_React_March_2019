export function users(defStore=[],action){
       
    switch(action.type){
        case "INCREMENT_FOLLOWERS":              
                console.log(action.identifier); 
                var index = defStore.findIndex(u => u.id == action.identifier);
                return [
                        ...defStore.slice(0,index),
                        {...defStore[index],followers:defStore[index].followers + 1},
                        ...defStore.slice(index+1)
                ];
        case "DECREMENT_FOLLOWERS":
                console.log('INCREMENT_FOLLOWERS');
                return defStore; //return a new Store
        case "ADD_USER":
                console.log('ADD_USER');
                return defStore; //return a new Store
        case "DELETE_USER":              
                var newUsersList = defStore.filter(u => u.id != action.identifier );
               return newUsersList; //return a new Store
        case "LOAD_USERS":
               return defStore;
        case "LOAD_USERS_ASYNC":
                        return action.response;
        default:      
                return defStore;
    }
}