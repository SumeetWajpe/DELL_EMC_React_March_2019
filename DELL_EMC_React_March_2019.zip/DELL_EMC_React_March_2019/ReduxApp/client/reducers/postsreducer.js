export function posts(defStore=[],action){
    switch(action.type){
        case "ADD_POSTS":
                console.log('ADD_POSTS');
                console.log(defStore);

                return defStore; //return a new Store
        case "DELETE_POSTS":
                console.log('DELETE_POSTS');
                return defStore; //return a new Store   
                
        default:
                return defStore;
    }
}