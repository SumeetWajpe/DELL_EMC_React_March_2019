
export function IncrementFollowers(identifier){
    return {
        type:'INCREMENT_FOLLOWERS',identifier
    }
}

export function DecrementFollowers(){
    return {
        type:'DECREMENT_FOLLOWERS'
    }
}

export function AddUser(){
    return {
        type:'ADD_USER'
    }
}

export function RemoveUser(identifier){
    return {
        type:'DELETE_USER',identifier
    }
}


export function LoadUsers(){
    return {
        type:'LOAD_USERS'
    }
}