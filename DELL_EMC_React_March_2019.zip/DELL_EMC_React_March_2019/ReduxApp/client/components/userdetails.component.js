import React from 'react';


export class UserDetails extends React.Component{
    render(){
        var theUserId = this.props.params.id;
        let currUser = this.props.allusers.find(u => u.id == theUserId);
            // use <React.Fragment> in v16.2.0
        return   ( <div> <div className="row">
                        <div className="col-md-10">
                            <img src={currUser.avatar_url} 
                            className="img-thumbnail"/>
                        </div>
                </div>
                <div className="row">
            <div className="col-md-6">
            <h1> Name :  {currUser.login}</h1>
            </div>
        </div>
        <div className="row">
            <div className="col-md-6">
            <h1> Type: {currUser.type}</h1>
            </div>
        </div>
        <div className="row">
            <div className="col-md-6">
            <button  className="btn btn-primary" 
            onClick={this.props.IncrementFollowers.bind(null,theUserId)} >
                            {currUser.followers}
                            <span className="glyphicon glyphicon-user">
                      </span>
            </button>
            </div>
        </div>
        </div>);
       
    }
}