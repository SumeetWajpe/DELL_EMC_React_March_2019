import React from 'react';
import { UserThumbnail } from './userthumbnail.component';


export class UsersComponent extends React.Component{
    render(){
        var usersToBeCreated = this.props.allusers.map(u=><UserThumbnail theUser={u} key={u.id} {...this.props}/>)
        return <div className="row">           
                        {usersToBeCreated}
            </div>
    }
}