import {takeEvery,put,call} from 'redux-saga/effects';
import axios from 'axios';

export function* getUsersAsync(){
    // get the ajax response & dispatch the action !
    const response =  yield call(axios.get,"https://api.myjson.com/bins/wc1iy");
    yield put({type:'LOAD_USERS_ASYNC',response:response.data})
}

export function* watchgetUsers(){
    yield takeEvery('LOAD_USERS',getUsersAsync)
}