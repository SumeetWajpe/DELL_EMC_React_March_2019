import React from 'react';
import logo from './logo.svg';
import './App.css';
import Course,{Add} from './course.component';

class App extends React.Component {
  constructor(){
    super(); // make sure to call  !
    this.courses = [
      {name: "React",price:2000,duration:'3 Days'},
      {name: "Angular",price:3000,duration:'5 Days'},
      {name: "Redux",price:3500,duration:'2 Days'}
      ];
  }
  render() {
    var coursesToBeCreated = this.courses.map(c=><Course coursedetails={c} />);
    return (
     <div>  
        {coursesToBeCreated}
      </div>
    );
  }
}

export default App;
