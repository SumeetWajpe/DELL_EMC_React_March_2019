import React from 'react';

export default class ButtonComponent extends React.Component{      

    constructor(props){
        super(props);
        this.state = {currCount:this.props.count};
    }
    IncrementCount(){
       this.setState({currCount:this.state.currCount+1})
        console.log('Inside IncrementCount..')
    }
    render(){
        //return <input type="button" value={this.props.count}  />
        return <button className="btn btn-primary" onClick={this.IncrementCount.bind(this)}>
                       {this.state.currCount}
                 </button>
    }
}

