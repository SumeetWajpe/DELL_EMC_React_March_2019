import React from 'react';

export default class CourseComponent extends React.Component{
    render(){
        return  (<div>
           <h1> {this.props.coursedetails.name} </h1>
           <b> Price : {this.props.coursedetails.price}</b><br/>
           <b> Duration : {this.props.coursedetails.duration}</b>
            </div> )
    }
}

export function Add(x,y){
    return x + y;
}