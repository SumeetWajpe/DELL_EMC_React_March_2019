import React from 'react';
import CustomButton from './burron.component';

export default class ListOfButtonsComponent extends React.Component{
   
    constructor(){
        super();
        this.state ={buttonlist: [10,20,30,40,50]};
    }   
    AddNewButton(){      
        var newButton = +(this.refs.txtInput.value);
        this.setState({buttonlist:[...this.state.buttonlist,newButton]})
        //  this.state.buttonlist.push(60);
        // this.setState({buttonlist:this.state.buttonlist})
    }
    render(){
        var btnsToBeCreated = this.state.buttonlist.map(b => 
        <CustomButton count={b} />)
        return <div>
            <p> Add New Button : <input type="number" ref="txtInput" />
            <input type="button" 
            onClick={this.AddNewButton.bind(this)}
            value="Add"
            className="btn btn-success"           
            />
            </p>
            {btnsToBeCreated}
        </div>
    }
}

